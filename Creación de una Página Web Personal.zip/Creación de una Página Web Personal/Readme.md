# Página Web Personal - Adrian Serran Martin

Actividad práctica para aprender a crear una página web sencilla, aplicar estilos con CSS y gestionar el proyecto con Git y GitHub.

## Contenido
- Nombre e identificación
- Frase personal
- Imagen/avatar (opcional)
- Estilos básicos con CSS